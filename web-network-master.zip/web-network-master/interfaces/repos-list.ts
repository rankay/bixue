export interface RepoInfo {
  id: number;
  githubPath: string;
}

export type ReposList = RepoInfo[];
