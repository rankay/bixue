export interface BalanceState {
  eth: number;
  staked: number;
  bepro: number;
}
