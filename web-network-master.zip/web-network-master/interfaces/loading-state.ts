export interface LoadingState {
  isLoading: boolean;
  text?: string;
}
