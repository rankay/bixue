export enum NetworkIds {
  Ethereum = 1,
  Kovan = 42,
  Ropsten = 3,
  Rinkeby = 4,
  Goerli = 5,
  Moonriver = 1285,
}
