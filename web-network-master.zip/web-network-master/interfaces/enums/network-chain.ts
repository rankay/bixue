// To identifier more Networks, visite: 
// https://chainlist.org/
export enum NetworkChain{
  Kovan = 42,
  Mainnet = 1,
  Ropsten = 3,
  Rinkeby = 4,
  Goerli = 5,
  Moonriver = 1285,
}