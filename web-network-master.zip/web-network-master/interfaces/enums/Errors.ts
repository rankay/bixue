export enum Errors {
  WalletNotConnected = `Wallet not connected`,
}